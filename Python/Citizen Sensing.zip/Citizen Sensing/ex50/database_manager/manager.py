import pymongo
from pymongo import MongoClient
from flask import Flask, jsonify, request
from datetime import datetime

MONGO_HOST = "mongodb://root:root@ds117848.mlab.com:17848/nodelogin"
MONGO_PORT = 23456
MONGO_DB = "nodelogin"
MONGO_USER = "root"
MONGO_PASS = "root"
connection = MongoClient(MONGO_HOST, MONGO_PORT)
mongo = connection[MONGO_DB]

class DatabaseManager:        
    def getData(self):
        data = mongo.db.data
        output = []
        for q in data.find():
            output.append({'name':q['username']})
        return jsonify({'result':output})
            
    def getUserSubmittedData(self, username):
        data = mongo.db.data
        output = []
        for q in data.find({'username': username}):
            output.append({'latitude':q['latitude'],'longitude':q['longitude'], 'time':q['time']})
        return jsonify({'result':output})
    
    def saveData(self, name, latitude, longitude, value):
        data = mongo.db.data
        currTime = str(datetime.now())
        
        save_id = data.insert({'username': name, 'latitude':latitude, 'longitude' : longitude, 'value' : value, 'time':currTime})
        new_data = data.find_one({'_id' : save_id})
        output = {'name' : new_data['username'], 'value':new_data['value']}
        return jsonify({'result':output})