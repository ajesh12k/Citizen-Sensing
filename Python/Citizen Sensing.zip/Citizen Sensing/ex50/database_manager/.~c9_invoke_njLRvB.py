import json, os, datetime
import pymysql.cursors

from database_manager.location_manager import LocationManager
from database_manager.distance_manager import DistanceManager

class DatabaseManager:
    def __init__(self):
        with open(os.path.join(os.path.dirname(__file__), 'config.json'), 'r') as myfile:
            self.config = json.load(myfile)
        
        self.connections = []
        self.location = LocationManager()
        self.distance = DistanceManager()
        self.connection_by_county = {}
        self.connection_by_uni_id = {}
        
        for connection_config in self.config:
            connection = pymysql.connect(host=connection_config['host'],
                         user=connection_config['user'],
                         password=connection_config['password'],
                         db=connection_config['db'],
                         charset='utf8mb4',
                         cursorclass=pymysql.cursors.DictCursor,
                         autocommit=True)
            self.connections.append(connection)
            
            self.connection_by_county[connection_config['location']] = connection
            self.connection_by_uni_id[connection_config['uni_id']] = connection
    
    def get_connection_by_ip(self, ip):
        ip_location = self.location.get_location(ip)
        
        print "location " + ip_location
        if self.connection_by_county.has_key(ip_location):
            return self.connection_by_county[ip_location]
        
        return self.get_closest_connection(ip_location)
        
    def get_closest_connection(self, client_location):
        smallest_distance = float("inf")
        closest_location = ''
        
        for db_location in self.connection_by_county.keys():
            dist = self.distance.get_distance(db_location, client_location)
            if dist < smallest_distance:
                smallest_distance = dist
                closest_location = db_location
        
        print closest_location
        return self.connection_by_county[closest_location]
            
    def get_course(self, course_name, university_id):
        sql = "SELECT * FROM course WHERE course_name=%s"
        with self.connection_by_uni_id[int(university_id)].cursor() as cursor:
            cursor.execute(sql, (course_name))
            return json.dumps(cursor.fetchall())
            
    def register_for_a_course(self, course_name, student_name, university_id):
        now = datetime.datetime.now()
        date = now.strftime("%Y-%m-%d")
        sql_course = "SELECT id_course, exam_id_exam FROM course WHERE course_name=%s"
        sql_insert = 
        
    def get_cources_list(self):
        sql = "SELECT * FROM course"
        result = []
        for conn in self.connections:
            with conn.cursor() as cursor:
                cursor.execute(sql)
                result += cursor.fetchall()
        return json.dumps(result)
        
    def get_uni_list(self, ip):
        with self.get_connection_by_ip(ip).cursor() as cursor:
            sql = "SELECT `id_university`, `uni_name`, `country`, `uni_location` FROM `university`"
            cursor.execute(sql)
            result = cursor.fetchall()
            return json.dumps(result)
    
    def add_user(self, ip, name, password, birthdate, major, university_id):
        connection = self.get_connection_by_ip(ip)
        with connection.cursor() as cursor:
            sql = "INSERT into `student` (student_name, major, password, student_dob, university_id_university) VALUES (%s, %s, %s, %s, %s)"
            print sql % (name, major, password, birthdate, university_id)
            cursor.execute(sql, (name, major, password, birthdate, int(university_id)))
            
    def get_user(self, name, password, university_id):
        print university_id
        print self.connection_by_uni_id
        with self.connection_by_uni_id[int(university_id)].cursor() as cursor:
            sql = "SELECT * FROM student WHERE student_name=%s"
            cursor.execute(sql, (name))
            result = cursor.fetchone()
            if not result:
                return json.dumps({'status': 'No such user'})
            if result['password'] != password:
                return json.dumps({'status': 'Wrong password'})
            return json.dumps({'status': 'Success'})

            
            
            