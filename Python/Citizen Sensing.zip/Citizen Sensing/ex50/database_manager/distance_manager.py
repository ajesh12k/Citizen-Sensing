import urllib2, json

class DistanceManager:
    def __init__(self):
        self.cached_distances = {}

    # make unique key for each two countries
    def make_key(self, locationA, locationB):
        locations = [locationA.lower(), locationB.lower()]
        locations.sort()
        return '|'.join(locations)

    # same logic as for location
    def get_distance(self, locationA, locationB):
        key = self.make_key(locationA, locationB)
        
        if self.cached_distances.has_key(key):
            return self.cached_distances[key]
        
        url = "http://www.distance24.org/route.json?stops=" + key 
        distance = int(json.load(urllib2.urlopen(url))['distance'])
        self.cached_distances[key] = distance
        return distance
        
# http://www.distance24.org/route.json?stops=Hamburg|Berlin