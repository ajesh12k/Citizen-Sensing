import urllib2, os, json

class LocationManager:
    def __init__(self):
        self.cached_locations = {}
        with open(os.path.join(os.path.dirname(__file__), 'location_config.json'), 'r') as myfile:
            self.config = json.load(myfile)
        
    def get_location(self, ip):
        # if cached, just return that
        if self.cached_locations.has_key(ip):
            return self.cached_locations[ip]
        # or else get from API and cache it
        else:
            location = self.get_location_from_API(ip).split(';')[4]
            self.cached_locations[ip] = location
            return location
            
    def get_location_from_API(self, ip):
        url = "{}?key={}&ip={}".format(self.config['host'], self.config['key'], ip)
        return urllib2.urlopen(url).read()